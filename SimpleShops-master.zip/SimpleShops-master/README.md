<img align="center" src="https://www.dropbox.com/s/7c108klxo44ysac/Simple-Shops.png?raw=1">

<h2 align="center">Documentation</h2>
<p align="center">
  <b>
    <a href="https://github.com/Ppgtjmad/SimpleShops/wiki">Wiki</a>
  </b>
</p>

<h2 align="center">Issues</h2>
<p align="center">
  <b>
    <a href="https://github.com/Ppgtjmad/SimpleShops/issues">Tickets</a>
  </b>
</p>

<h2 align="center">Credits</h2>
<p align="center">
  <b>
    Icons<br/>
    <a href="http://flaticons.net/" target="_blank">FlatIcons</a><br/>
    Spanish translation<br/>
    <a href="https://github.com/TteMerino" target="_blank">TteMerino</a><br/>
    Chinese translation<br/>
    <a href="http://steamcommunity.com/profiles/76561198112435564/" target="_blank">Atlas1205</a> | <a href="https://steamcommunity.com/id/1625592417/" target="_blank">strayer-迷幻</a><br/>
    Russian translation<br/>
    <a href="https://forums.bohemia.net/profile/1166121-vitalyturbovaz/" target="_blank">VitalyTurboVaz</a><br/>
    Logo<br/>
    <a href="http://steamcommunity.com/profiles/76561198030800949/" target="_blank">N3V3RD134l0N3</a>
  </b>
</p>

<h2 align="center">Donate</h2>
<p align="center">
  <b>
    Liking my work? Please consider donating some BEP20 crypto, even little helps a ton!<br/>
	  <a href="https://link.trustwallet.com/send?coin=20000714&address=0xF1E4BbD02607273AAF401A8D541884b6DC4c6990" target="_blank">Trust Wallet</a><br/>
	  <a href="https://bscscan.com/address/0xF1E4BbD02607273AAF401A8D541884b6DC4c6990" target="_blank">0xF1E....4c6990</a>
  </b>
</p>

<h2 align="center">License</h2>
<p align="center">
  <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png"/></a><br/>This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.
</p>
