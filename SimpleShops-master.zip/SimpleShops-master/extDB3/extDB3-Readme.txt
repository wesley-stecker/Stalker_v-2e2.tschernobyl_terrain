extDB3 Description
extDB3 is an Arma3 Addon for connecting to Databases (currently only MariaDB/MySQL).
The main purpose for extDB3 is for persistent missions in Arma.
Note it will require some knowledge about SQF & SQL to use.
extDB3 is also designed to be flexible & secure at the same time.

More Info available @ wiki https://bitbucket.org/torndeco/extdb3/wiki/Home
