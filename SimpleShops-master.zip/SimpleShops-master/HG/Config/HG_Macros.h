/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define false 0
#define true  1
