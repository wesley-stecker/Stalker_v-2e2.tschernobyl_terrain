#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_TAGS_DISP         (uiNamespace getVariable ["HG_Tags",displayNull])
#define HG_TAGS_TEXT         (HG_TAGS_DISP displayCtrl HG_TAGS_TEXT_IDC)
