#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_GARAGE_DISP            findDisplay HG_GARAGE_IDD
#define HG_GARAGE_INFO            (HG_GARAGE_DISP displayCtrl HG_GARAGE_INFO_IDC)
#define HG_GARAGE_LIST            (HG_GARAGE_DISP displayCtrl HG_GARAGE_LIST_IDC)
#define HG_GARAGE_SP              (HG_GARAGE_DISP displayCtrl HG_GARAGE_SP_IDC)
#define HG_GARAGE_REFRESH_BTN     (HG_GARAGE_DISP displayCtrl HG_GARAGE_REFRESH_BTN_IDC)
#define HG_GARAGE_SPAWN_BTN       (HG_GARAGE_DISP displayCtrl HG_GARAGE_SPAWN_BTN_IDC)
#define HG_GARAGE_DELETE_BTN      (HG_GARAGE_DISP displayCtrl HG_GARAGE_DELETE_BTN_IDC)
