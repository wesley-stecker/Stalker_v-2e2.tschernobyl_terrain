#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_GK_DISP                 findDisplay HG_GK_IDD
#define HG_GK_OWNERS_LIST          (HG_GK_DISP displayCtrl HG_GK_OWNERS_LIST_IDC)
#define HG_GK_PLAYERS_COMBO        (HG_GK_DISP displayCtrl HG_GK_PLAYERS_COMBO_IDC)
#define HG_GK_REMOVE_BTN           (HG_GK_DISP displayCtrl HG_GK_REMOVE_BTN_IDC)
#define HG_GK_REFRESH_BTN          (HG_GK_DISP displayCtrl HG_GK_REFRESH_BTN_IDC)
#define HG_GK_GIVE_BTN             (HG_GK_DISP displayCtrl HG_GK_GIVE_BTN_IDC)
