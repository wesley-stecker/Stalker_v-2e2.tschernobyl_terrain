#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_HUD_DISP               (uiNamespace getVariable [HG_HUD_TYPE,displayNull])
#define HG_HUD_XP_BACK            (HG_HUD_DISP displayCtrl HG_HUD_XP_BACK_IDC)
#define HG_HUD_XP_PIC             (HG_HUD_DISP displayCtrl HG_HUD_XP_PIC_IDC)
#define HG_HUD_XP_TEXT            (HG_HUD_DISP displayCtrl HG_HUD_XP_TEXT_IDC)
#define HG_HUD_KILL_COUNT_BACK    (HG_HUD_DISP displayCtrl HG_HUD_KILL_COUNT_BACK_IDC)
#define HG_HUD_KILL_COUNT_PIC     (HG_HUD_DISP displayCtrl HG_HUD_KILL_COUNT_PIC_IDC)
#define HG_HUD_KILL_COUNT_TEXT    (HG_HUD_DISP displayCtrl HG_HUD_KILL_COUNT_TEXT_IDC)
#define HG_HUD_RANK_PIC           (HG_HUD_DISP displayCtrl HG_HUD_RANK_PIC_IDC)
#define HG_HUD_RANK_TEXT          (HG_HUD_DISP displayCtrl HG_HUD_RANK_TEXT_IDC)
#define HG_HUD_MONEY_TEXT         (HG_HUD_DISP displayCtrl HG_HUD_MONEY_TEXT_IDC)
