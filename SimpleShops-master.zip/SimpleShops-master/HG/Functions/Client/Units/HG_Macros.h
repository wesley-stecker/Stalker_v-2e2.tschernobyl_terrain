#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_UNITS_SHOP_DISP          findDisplay HG_UNITS_SHOP_IDD
#define HG_UNITS_PRICE	           (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_PRICE_IDC)
#define HG_UNITS_ITEM_PIC          (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_ITEM_PIC_IDC)
#define HG_UNITS_ITEM_TEXT         (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_ITEM_TEXT_IDC)
#define HG_UNITS_TREE              (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_TREE_IDC)
#define HG_UNITS_UNIT_SWITCH       (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_UNIT_SWITCH_IDC)
#define HG_UNITS_BUY_BTN           (HG_UNITS_SHOP_DISP displayCtrl HG_UNITS_BUY_BTN_IDC)