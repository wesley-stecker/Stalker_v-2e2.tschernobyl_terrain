#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_VEHICLES_SHOP_DISP     findDisplay HG_VEHICLES_SHOP_IDD
#define HG_VEHICLES_TEXT          (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_TEXT_IDC)
#define HG_VEHICLES_SWITCH	      (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_SWITCH_IDC)
#define HG_VEHICLES_LIST		  (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_LIST_IDC)
#define HG_VEHICLES_COLORS        (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_COLORS_IDC)
#define HG_VEHICLES_SP            (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_SP_IDC)
#define HG_VEHICLES_TG            (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_TG_IDC)
#define HG_VEHICLES_BUY           (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_BUY_IDC)
#define HG_VEHICLES_MC            (HG_VEHICLES_SHOP_DISP displayCtrl HG_VEHICLES_MC_IDC)
