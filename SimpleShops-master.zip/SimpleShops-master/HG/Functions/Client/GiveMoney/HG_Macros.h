#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#define HG_GM_DISP                findDisplay HG_GM_IDD
#define HG_GM_EDIT                (HG_GM_DISP displayCtrl HG_GM_EDIT_IDC)
