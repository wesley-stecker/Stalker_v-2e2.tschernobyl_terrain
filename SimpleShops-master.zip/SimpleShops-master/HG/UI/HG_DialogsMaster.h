/*
    Author - HoverGuy
    Website - https://northernimpulse.com
*/

#include "HG_ControlTypes.h"
#include "Dialogs\HG_AdminMenu.h"
#include "Dialogs\HG_ATM.h"
#include "Dialogs\HG_Dealer.h"
#include "Dialogs\HG_Garage.h"
#include "Dialogs\HG_GearShop.h"
#include "Dialogs\HG_GiveKey.h"
#include "Dialogs\HG_GiveMoney.h"
#include "Dialogs\HG_ItemsShop.h"
#include "Dialogs\HG_Trader.h"
#include "Dialogs\HG_UnitsShop.h"
#include "Dialogs\HG_VehiclesShop.h"
